<?php
$hostname = 'bariskode.online';
$username = 'bariskod';
$password = 'passforlife9';
$dbname = 'bariskod_db_bisniskeluarga2';

$conn = mysqli_connect($hostname, $username, $password, $dbname) or die ('Gagal terhubung ke database');


?>